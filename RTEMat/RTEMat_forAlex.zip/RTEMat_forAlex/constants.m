% This routine will provide values and units for all the 
% universal constants that I needed in my work.
%
% Reference: "The 1986 racommended values of the fundamental physical constants"
% 
% Usage:
%       [const,units]=constants(string);
% Input:
%       string: String specifying which constant is needed
%               Avalaible right now:
%               'planck'            Planck constant [J Hz-1] 
%               'boltzmann'         Boltzmann constant [J K-1]  
%               'light'             Light speed [m s-1]  
%               'Np2dB'             Neper to Decibel [dB/Np]  
%               'EarthRadius'       Earth radius [km]
%               'Rdry'              Gas constant of dry air [J kg-1 K-1]
%               'Rwatvap'           Gas constant of water vapor [J kg-1 K-1]
%               'Tcosmicbkg'        Cosmic Background Temperature [K]
% Outputs:
%         const: Numerical Value of the asked constant
%         units: String specifying which units are used
% Es:   
%       [h,units]=constants('planck');
%
% Nico, 2000
% 
% History
% 2003/06/06 - Added 'Rdry' and 'Rwatvap'
% 2005/12/10 - Added 'Tcosmicbkg'

function [out,units]=constants(strng)

switch strng
   
   case 'planck'
      h=6.6260755 * 1e-34; % [J Hz-1] Planck constant 
      units='[J Hz-1]';
      out=h;
   case 'boltzmann'
      K=1.380658 * 1e-23; % [J K-1] Boltzmann constant
      units='[J K-1]';
      out=K;
   case 'light'
      c=299792458; % [m s-1] Light speed
      units='[m s-1]';
      out=c;
   case 'Np2dB'
      Np2dB=10*log10(exp(1));
      units='[dB/Np]';
      out=Np2dB;
   case 'EarthRadius'
      R=6370.949; % [Km] Earth radius
      units='[Km]';
      out=R;
   case 'Rdry'
      Rd=287.04; % [J kg-1 K-1] Gas constant of dry air
      units='[J kg-1 K-1]';
      out=Rd;
   case 'Rwatvap'
      Rv=461.50; % [J kg-1 K-1] Gas constant of water vapor 
      units='[J kg-1 K-1]';
      out=Rv;
   case 'Tcosmicbkg'
      Tcos = 2.736; % +/- 0.017 [K] Cosmic Background Temperature, from Janssen, Atmospheric Remote Sensing by Microwave Radiometry, pag.12
      units='[K]';
      out=Tcos;
     
   otherwise
      fprintf(1,' No constant avalaible with this name: "%s" . Sorry... \n',strng)
      out=[];
      units=[];
      
end