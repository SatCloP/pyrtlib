% Test for RTE Matlab functions (developed from RTE fortran routines).
%
% Nico, Oct 2016

% Settings
% Channel requency
frq = [22.24; 23.04; 23.84; 25.44; 26.24; 27.84; 31.40; 51.26; 52.28; 53.86; 54.94; 56.66; 57.30; 58.00]';
% Elevation angle
ang = 90.;
% Clear/Cloudy
cloudy = 1;
% Absorption model
AM = 'rosen';        % differences wrt fortran routines <=0.01 K (clear and cloudy)
%AM = 'ros03';       % differences wrt fortran routines <=0.01 K (clear and cloudy)
%AM = 'L87';         % yet to translate...
%AM = 'L93';         % yet to translate...
%AM = 'Lilje04';     % yet to translate...

% Loading RAOB data
load test_RTEMat.mat
nrb = length(RAOB);

% Processing & printout
nf = length(frq);
fprintf(1,['        PWV(cm) LWP(cm) IWP(cm) ' repmat('%6.2f ',1,nf) ' \n'],frq);
for i = 1:nrb
   
  z = RAOB(i).ZKm;
  p = RAOB(i).Pmb;
  t = RAOB(i).TK;
  rh= RAOB(i).RH;
  denliq = zeros(size(z)); % no cloud
  denice = zeros(size(z)); % no cloud
  cldh = zeros(2,0);
  if cloudy
     % build a cloud
     ib = 2; it = 4; denliq(ib:it) = 10*ones(it-ib+1,1); cldh(:,1) = [z(ib); z(it)]; 
     ib = 30; it = 32; denice(ib:it) = 0.1*ones(it-ib+1,1); cldh(:,2) = [z(ib); z(it)]; 
  end
  
  MAT = TbCloud_RTE(z,p,t,rh,denliq,denice,cldh,frq,ang,AM);
  
  fprintf(1,['%s:\t %6.2f  %6.2f  %6.2f ' repmat('%6.2f ',1,nf) '\n'],AM,MAT.srho,MAT.sliq,MAT.sice,MAT.tbtotal);
  
end  
